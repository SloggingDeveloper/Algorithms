'use strict';

(function () {

    const isSpecficCharRepetition = function (word, index) {
        return (index + 1) <= word.length && word[index] !== '*' && word[index] !== '.' && word[index + 1] === '*';
    };

    const isAnyCharRepitition = function (word, index) {
        return (index + 1) <= word.length && word[index] === '.' && word[index + 1] === '*';
    };

    const isAnySingleChar = function (word, index) {
        return (index + 1) <= word.length && word[index] === '.' && word[index + 1] !== '*'
    };


    const tokenizeRegex = function (pattern) {
        let split = pattern.split('');
        let tokenized = [];
        for (let i = 0; i < split.length; i++) {
            if (isAnyCharRepitition(split, i) || isSpecficCharRepetition(split, i)){
                tokenized.push(split[i] + split[i + 1]);
                i++;
            }
            else
                tokenized.push(split[i]);
        }
        return tokenized;
    };

    const getMatchMatrix = function (word, pattern) {
        let wordSplit = word.split('');
        let tokenizedPattern = tokenizeRegex(pattern);
        let matrix = [];
        for (let i = 0; i < tokenizedPattern.length; i++) {
            matrix[i] = [];
            for (let j = 0; j < wordSplit.length; j++) {
                matrix[i][j] = false;
            }
        }

        for (let i = 0; i < tokenizedPattern.length; i++) {
            //case 1:
            if (isAnyCharRepitition(tokenizedPattern[i].split(''), 0)) {
                for (let j = i; j < wordSplit.length; j++) {
                    if (i > 0 && j > 0)
                        matrix[i][j] = true && matrix[i - 1][j - 1];
                    else
                        matrix[i][j] = true;
                }
            }

            else if (isSpecficCharRepetition(tokenizedPattern[i].split(''), 0)) {
                let char = tokenizedPattern[i][0];
                for (let j = i; j < wordSplit.length && wordSplit[j] === char; j++) {
                    if (i > 0 && j > 0)
                        matrix[i][j] = true && matrix[i - 1][j - 1];
                    else
                        matrix[i][j] = true;
                }
            }

            else {
                if (tokenizedPattern[i - 1] && (isAnyCharRepitition(tokenizedPattern[i-1].split(''), 0) || isSpecficCharRepetition(tokenizedPattern[i-1].split(''), 0))) {
                    if (tokenizedPattern[i] === wordSplit[i - 1]) {
                        matrix[i][i - 1] = true && matrix[i - 1][i - 1];
                    }
                    else{
                        matrix[i][i] =true && matrix[i - 1][i - 1];
                    }
                }

                else if (tokenizedPattern[i] === wordSplit[i]) {
                    if (i > 0)
                        matrix[i][i] =true && matrix[i - 1][i - 1];
                    else
                        matrix[i][i] = true;
                }
            }
        }

        return matrix;
    };

    

    const isMatch = function (word, pattern) {
        let matrix = getMatchMatrix(word, pattern);
        return matrix[matrix.length-1][matrix[0].length - 1];
    };

    module.exports = isMatch;
})();